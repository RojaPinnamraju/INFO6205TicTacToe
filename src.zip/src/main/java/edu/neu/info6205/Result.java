package edu.neu.info6205;

public enum Result {
    Alpha,
    Beta,
    Gamma,
    Delta
}