package edu.neu.info6205.player;

import edu.neu.info6205.Board;
import edu.neu.info6205.Result;

public abstract class Player {

    private char myChar;

    public Player(char myChar){
        this.myChar = myChar;
    }

    public abstract Board makeMove(Board board);

    public void winner(Result result){};

    public char getMyChar(){
        return myChar;
    }

}
