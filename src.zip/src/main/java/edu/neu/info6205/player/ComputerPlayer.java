package edu.neu.info6205.player;

import edu.neu.info6205.Board;
import edu.neu.info6205.FileUtil;
import edu.neu.info6205.player.menace.Matchbox;

import java.util.List;
import java.util.Random;

public class ComputerPlayer extends Player {
    Random rng;
    public ComputerPlayer(char myChar) {
        super(myChar);
        rng = new Random();
    }

    @Override
    public Board makeMove(Board board) {

        List<Integer> availableMoves = board.availableMoves();
        int move=0;
        if(Matchbox.pattern=="") {
             move = availableMoves.get(rng.nextInt(availableMoves.size()));
        }
        else {
             move = FileUtil.readData(Matchbox.pattern, true);
             if(move==0)move = availableMoves.get(rng.nextInt(availableMoves.size()));
        }
        //move = availableMoves.get(rng.nextInt(availableMoves.size()));
        Matchbox.pattern+=String.valueOf(move);
        Matchbox.patternList.add(new Long(Matchbox.pattern));
        System.out.println("cp move "+move);
        board.makeMove(move, getMyChar());
        return board;
    }

}
