package edu.neu.info6205.player.menace;

import edu.neu.info6205.Board;
import edu.neu.info6205.FileUtil;
import edu.neu.info6205.Result;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;

public class Matchbox {
    private static final int Gamma = -3;
    private static final int Beta = 5;
    private static final int Delta = 1;
    private final int Alpha = 7;

    public static Hashtable <String, Integer> learnHashtable= new Hashtable<>();

    public static String pattern="";

    public static List<Long> patternList=new ArrayList<>();

    private Board board;
    private List<Integer> moveBeads;
    List<Integer> availableMoves;

    Random rng;

    public Matchbox(Board board){
        this.board = new Board(board);
        availableMoves = board.availableMoves();
        moveBeads = new ArrayList<>();
        for (Integer ignored : availableMoves) {
            moveBeads.add(Alpha);
        }

        rng = new Random();
    }


    public int getMove(){
        int totalBeads = 0;
        for (Integer moveBead : moveBeads) {
            totalBeads += moveBead;
        }

//        if (totalBeads > 56) {
//            // if the box is empty, make a random move (it doesn't matter you should quit anyway)
//            int move = 5;
//            //System.out.println(move);
//            return move;
//        }
        char[][] test=board.getBoard();
        for(int i=0;i<3;++i) {

            //If any two of the humans Xs are in the row then go for the third one to win
            if (test[i][0] == test[i][1] && test[i][0] == 'X' && test[i][2]==' '){
                return i*3+3;
            }
            if (test[i][1] == test[i][2] && test[i][1] == 'X' && test[i][0]==' '){
                return i*3+1;
            }
            if (test[0][i] == test[1][i] && test[0][i] == 'X' && test[2][i]==' '){
                return 7+i;
            }
            if (test[1][i] == test[2][i] && test[1][i] == 'X' && test[0][i]==' '){
                return 1+i;
            }
            if (test[1][1] == test[2][2] && test[1][1] == 'X' && test[0][0]==' '){
                return 1;
            }
            if (test[1][1] == test[0][0] && test[1][1] == 'X' && test[2][2]==' '){
                return 9;
            }
            if (test[0][2] == test[1][1] && test[1][1] == 'X' && test[2][0]==' '){
                return 7;
            }
            if (test[2][0] == test[1][1] && test[1][1] == 'X' && test[0][2]==' '){
                return 3;
            }

            //Creating forks
            if(test[0][0]==test[2][2] && test[0][0]=='X')
            {
                if(test[0][2]==' ')
                    return 3;
                if(test[2][0]==' ')
                    return 7;
            }

            if(test[0][2]==test[2][0] && test[0][2]=='X')
            {
                if(test[0][0]==' ')
                    return 1;
                if(test[2][2]==' ')
                    return 9;
            }


            //Blocking corner forks
            if(test[0][0]==test[2][2] && test[0][0]=='O')
            {
                if(test[0][2]==' ')
                    return 3;
                if(test[2][0]==' ')
                    return 7;
            }

            if(test[0][2]==test[2][0] && test[0][2]=='O')
            {
                if(test[0][0]==' ')
                    return 1;
                if(test[2][2]==' ')
                    return 9;
            }

            if(test[1][1]==' ')
            {
                return 5;
            }

            //Opposite corners
            if (test[0][0] == 'O' &&  test[2][2]==' '){
                return 9;
            }
            if (test[0][2] == 'O' &&  test[2][0]==' '){
                return 7;
            }
            if (test[2][0] == 'O' &&  test[0][2]==' '){
                return 3;
            }
            if (test[2][2] == 'O' &&  test[0][0]==' '){
                return 1;
            }

            //Empty corners
            if (test[0][0] == ' ' ){
                return 1;
            }
            if (test[0][2] == ' ' ){
                return 3;
            }
            if (test[2][0] == ' '){
                return 7;
            }
            if (test[2][2] == ' '){
                return 9;
            }

            //Empty sides
            if (test[1][0] == ' '){
                return 4;
            }
            if (test[0][1] == ' '){
                return 2;
            }
            if (test[1][2] == ' '){
                return 6;
            }
            if (test[2][1] == ' '){
                return 8;
            }


            //If any two of the computers 0s are in the row then block the third one to avoid loss
            if (test[i][0] == test[i][1] && test[i][0] == 'O' && test[i][2]==' '){
                return i*3+3;
            }
            if (test[i][1] == test[i][2] && test[i][1] == 'O' && test[i][0]==' '){
                return i*3+1;
            }
            if (test[0][i] == test[1][i] && test[0][i] == 'O' && test[2][i]==' '){
                return 7+i;
            }
            if (test[1][i] == test[2][i] && test[1][i] == 'O' && test[0][i]==' '){
                return 1+i;
            }

        }

        int randomSelection = rng.nextInt(totalBeads);
        int moveIndex = -1;

        do {
            moveIndex++;
            randomSelection -= moveBeads.get(moveIndex);
        } while (randomSelection > 0);
        //System.out.println(availableMoves.get(moveIndex));
        return availableMoves.get(moveIndex);

    }

    public void learn(int move, Result result) {
        // learn from the result i.e. add or remove beads for the move

        int beadChange = 0;
        switch (result) {
            case Gamma:
                beadChange = Gamma;
                break;
            case Beta:
                beadChange = Beta;
                break;
            case Delta:
                beadChange = Delta;
                break;
        }
            for (int i = 0; i < Matchbox.patternList.size(); i++) {
                long key = patternList.get(i);
                if (Matchbox.learnHashtable.contains(key)) {
                    int getBeadCount = learnHashtable.get(key);
                    learnHashtable.replace(String.valueOf(key), getBeadCount + beadChange);
                } else {
                    learnHashtable.put(String.valueOf(key), Alpha + beadChange);
                }
            }

        learnHashtable.entrySet().forEach( entry -> {
            String[] entryStringArray= {entry.getKey(),String.valueOf(entry.getValue())};
            FileUtil.writeData(entryStringArray);
            });


    }

    public Board getBoard() {
        return board;
    }
}
